package Utilerias;

public class Archivo {

    public static java.util.ArrayList Leer(String nom) {
        java.util.ArrayList Lista = new java.util.ArrayList();
        try {
            java.io.FileInputStream fis = new java.io.FileInputStream(nom);
            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
            Lista = (java.util.ArrayList) ois.readObject();
            ois.close();
        } catch (Exception ex) {
            System.out.println("Error al leer el archivo" + ex.toString());
        }
        return Lista;
    }

    public static void guardar(String nom, java.util.ArrayList Lista) {
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream(nom);
            java.io.ObjectOutputStream oss = new java.io.ObjectOutputStream(fos);
            oss.writeObject(Lista);
            oss.close();
        } catch (java.io.IOException ex) {
            System.out.println("Error al guardar en el archivo " + ex.toString());
        }
    }
}
