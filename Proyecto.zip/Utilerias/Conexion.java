
package Utilerias;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
    private Connection cxn = null;
    private String url = "jdbc:mysql://localhost:3306/PARADIGMAS_2";
    private String user = "root";
    private String password = "root";
    
    public Connection getConexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cxn = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            System.out.println("El driver JDBC no fue encontrado.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos.");
            e.printStackTrace();
        }
        return cxn;
    }
    
    public void closeConexion() {
        if (cxn != null) {
            try {
                cxn.close();
            } catch (SQLException ex) {
                System.out.println("Error al cerrar la conexión.");
                ex.printStackTrace();
            }
        }
    }
}
