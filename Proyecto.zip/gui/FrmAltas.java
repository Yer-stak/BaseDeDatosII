package gui;

import dao.DaoAlumno;
import model.Paradigmas_2;

public class FrmAltas extends javax.swing.JDialog implements java.awt.event.ActionListener {

    DaoAlumno daoAlumno = new DaoAlumno();
    public FrmAltas() {
        super.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();

        super.setSize(d);
        super.setTitle("ALTAS ALUMNOS");
        super.setLayout(null);
        
         

        // Matricula
        lblMatricula = new javax.swing.JLabel("Matricula:");
        lblMatricula.setBounds(10, 10, 200, 30);
        txtMatricula = new javax.swing.JTextField(10);
        txtMatricula.setBounds(210, 10, 150, 30);

        // Nombre
        lblNombre = new javax.swing.JLabel("Nombre:");
        lblNombre.setBounds(10, 50, 200, 30);
        txtNombre = new javax.swing.JTextField(10);
        txtNombre.setBounds(210, 50, 150, 30);

        // Apellido
        lblApellido = new javax.swing.JLabel("Apellido:");
        lblApellido.setBounds(10, 90, 200, 30);
        txtApellido = new javax.swing.JTextField(10);
        txtApellido.setBounds(210, 90, 150, 30);

        // Carrera
        lblCarrera = new javax.swing.JLabel("Carrera:");
        lblCarrera.setBounds(10, 130, 200, 30);
        cmbCarrera = new javax.swing.JComboBox<>();
        cmbCarrera.setBounds(210, 130, 150, 30);

        // Cargar carreras en el ComboBox
        dao.DaoCarrera daoCarrera = new dao.DaoCarrera();
        java.util.ArrayList<model.Carrera> listaCarreras = daoCarrera.readCarrera();
        for (model.Carrera carrera : listaCarreras) {
            cmbCarrera.addItem(carrera.getNomCar());
        }

        // Edad
        lblEdad = new javax.swing.JLabel("Edad:");
        lblEdad.setBounds(10, 170, 200, 30);
        txtEdad = new javax.swing.JTextField(10);
        txtEdad.setBounds(210, 170, 150, 30);

        // Semestre
        lblSemestre = new javax.swing.JLabel("Semestre:");
        lblSemestre.setBounds(10, 210, 200, 30);
        txtSemestre = new javax.swing.JTextField(10);
        txtSemestre.setBounds(210, 210, 150, 30);

        //Botones
        btnGuardar = new javax.swing.JButton("Guardar");
        btnGuardar.setBounds(300, 250, 100, 30);
        btnRegresarMenu = new javax.swing.JButton("REGRESAR AL MENU PRINCIPAL");
        btnRegresarMenu.setBounds(10, 250, 250, 30);

        super.add(lblMatricula);
        super.add(txtMatricula);
        super.add(lblNombre);
        super.add(txtNombre);
        super.add(lblApellido);
        super.add(txtApellido);
        super.add(lblCarrera);
        super.add(cmbCarrera);
        super.add(lblEdad);
        super.add(txtEdad);
        super.add(lblSemestre);
        super.add(txtSemestre);
        super.add(btnGuardar);
        super.add(btnRegresarMenu);

        btnRegresarMenu.addActionListener(this);
        btnGuardar.addActionListener(this);
    }

    private void LimpiarCampos() {
        txtMatricula.setText("");
        txtNombre.setText("");
        txtApellido.setText("");
        cmbCarrera.setSelectedIndex(0);
        txtEdad.setText("");
        txtSemestre.setText("");
    }

    private void btnRegresarMenuActionPerfomed(java.awt.event.ActionEvent e) {
        this.dispose();
    }

    private void btnGuardarActionPerfomed(java.awt.event.ActionEvent e) {
        int mat;
        try {
            mat = Integer.parseInt(txtMatricula.getText());
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(null, 
                    "Ingrese una matrícula válida (número entero).");
            return;
        }

        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String carrera = (String) cmbCarrera.getSelectedItem();
        byte edad;
        byte semestre;

        try {
            edad = Byte.parseByte(txtEdad.getText());
            semestre = Byte.parseByte(txtSemestre.getText());
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(
                    null, "Ingrese valores válidos para edad"
                            + " y semestre (números enteros).");
            return;
        }

        Paradigmas_2 alum = new Paradigmas_2(mat, nombre, apellido, carrera, edad,
                semestre);
        daoAlumno.createAlumnos(alum);

        LimpiarCampos();
        javax.swing.JOptionPane.showMessageDialog(null, 
                "Alumno guardado con éxito.");
    }

    private javax.swing.JButton btnRegresarMenu;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JLabel lblMatricula;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblApellido;
    private javax.swing.JLabel lblCarrera;
    private javax.swing.JLabel lblEdad;
    private javax.swing.JLabel lblSemestre;
    private javax.swing.JTextField txtMatricula;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JComboBox<String> cmbCarrera;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtSemestre;

    @Override
    public void actionPerformed(java.awt.event.ActionEvent e) {
        if (e.getSource() == btnRegresarMenu) {
            btnRegresarMenuActionPerfomed(e);
        } else if (e.getSource() == btnGuardar) {
            btnGuardarActionPerfomed(e);
        }
    }
}
