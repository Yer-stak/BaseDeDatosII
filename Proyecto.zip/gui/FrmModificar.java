package gui;

import model.Paradigmas_2;

public class FrmModificar extends javax.swing.JDialog implements java.awt.event.ActionListener {

    public FrmModificar() {
        super.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();

        super.setSize(d);
        super.setTitle("MODIFICACIONES");
        super.setLayout(null);

        lblOpcs = new javax.swing.JLabel("BIENVENIDO A LA VENTANA DE MODIFICACIONES "
                + "ELIJE LA OPCION QUE DESEAS USAR");
        lblOpcs.setBounds(700, 10, 300, 40);

        btnModNom = new javax.swing.JButton("MODIFICAR NOMBRE");
        btnModNom.setBounds(700, 150, 300, 30);
        btnModNom.addActionListener(this);
        add(btnModNom);

        btnModAp = new javax.swing.JButton("MODIFICAR APELLIDO");
        btnModAp.setBounds(625, 200, 300, 30);
        btnModAp.addActionListener(this);
        add(btnModAp);

        btnModCa = new javax.swing.JButton("MODIFICAR CARRERA");
        btnModCa.setBounds(700, 250, 300, 30);
        btnModCa.addActionListener(this);
        add(btnModCa);

        btnModEd = new javax.swing.JButton("MODIFICAR EDAD");
        btnModEd.setBounds(625, 300, 300, 30);
        btnModEd.addActionListener(this);
        add(btnModEd);

        btnModSem = new javax.swing.JButton("MODIFICAR SEMESTRE");
        btnModSem.setBounds(700, 350, 300, 30);
        btnModSem.addActionListener(this);
        add(btnModSem);

        btnMenu = new javax.swing.JButton("REGRESAR AL MENU PRINCIPAL");
        btnMenu.setBounds(625, 400, 300, 30);
        btnMenu.addActionListener(this);
        add(btnMenu);

        super.add(lblOpcs);
        super.add(btnModNom);
        super.add(btnModAp);
        super.add(btnModCa);
        super.add(btnModEd);
        super.add(btnModSem);
        super.add(btnMenu);
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        lblMat = new javax.swing.JLabel("Matrícula:");
        lblMat.setBounds(50, 150, 100, 25);
        add(lblMat);

        txtMat = new javax.swing.JTextField();
        txtMat.setBounds(160, 150, 200, 25);
        add(txtMat);

        lblNom = new javax.swing.JLabel("Nuevo Nombre:");
        lblNom.setBounds(50, 185, 100, 25);
        add(lblNom);

        txtNom = new javax.swing.JTextField();
        txtNom.setBounds(160, 185, 200, 25);
        add(txtNom);

        lblAp = new javax.swing.JLabel("Nuevo Apellido:");
        lblAp.setBounds(50, 185, 100, 25);
        add(lblAp);

        txtAp = new javax.swing.JTextField();
        txtAp.setBounds(160, 185, 200, 25);
        add(txtAp);


        cmbCarrera = new javax.swing.JComboBox<>();
        cmbCarrera.setBounds(160, 185, 200, 25);

 
        dao.DaoCarrera daoCarrera = new dao.DaoCarrera();
        java.util.ArrayList<model.Carrera> listaCarreras = daoCarrera.readCarrera();
        for (model.Carrera carrera : listaCarreras) {
            cmbCarrera.addItem(carrera.getNomCar());
        }
        add(cmbCarrera);

        lblEd = new javax.swing.JLabel("Nueva Edad:");
        lblEd.setBounds(50, 185, 100, 25);
        add(lblEd);

        txtEd = new javax.swing.JTextField();
        txtEd.setBounds(160, 185, 200, 25);
        add(txtEd);

        lblSem = new javax.swing.JLabel("Nuevo Semestre:");
        lblSem.setBounds(50, 185, 100, 25);
        add(lblSem);

        txtSem = new javax.swing.JTextField();
        txtSem.setBounds(160, 185, 200, 25);
        add(txtSem);

        btnConfirmar = new javax.swing.JButton("CONFIRMAR");
        btnConfirmar.setBounds(160, 290, 200, 30);
        btnConfirmar.addActionListener(e -> {
            if (lblNom.isVisible()) {
                modificarNombre();
            } else if (lblAp.isVisible()) {
                modificarApellido();
            } else if (cmbCarrera.isVisible()) {
                modificarCarrera();
            } else if (lblEd.isVisible()) {
                modificarEdad();
            } else if (lblSem.isVisible()) {
                modificarSemestre();
            }
        });
        add(btnConfirmar);

        ocultarComponentes();
    }

    private void ocultarComponentes() {
        lblMat.setVisible(false);
        txtMat.setVisible(false);
        lblNom.setVisible(false);
        txtNom.setVisible(false);
        lblAp.setVisible(false);
        txtAp.setVisible(false);
        cmbCarrera.setVisible(false);
        lblEd.setVisible(false);
        txtEd.setVisible(false);
        lblSem.setVisible(false);
        txtSem.setVisible(false);
        btnConfirmar.setVisible(false);
    }

    private void modificarNombre() {
        try {
            int matriculaParaModificar = Integer.parseInt(txtMat.getText().trim());
            String nuevoNombre = txtNom.getText().trim();
            dao.DaoAlumno daoAlumnos = new dao.DaoAlumno();
            java.util.ArrayList<Paradigmas_2> listaAlumnos = daoAlumnos.readAlumnos();
            boolean alumnoEncontrado = false;

            for (Paradigmas_2 alumno : listaAlumnos) {
                if (alumno.getMat() == matriculaParaModificar) {
                    alumno.setNom(nuevoNombre);
                    alumnoEncontrado = daoAlumnos.updateAlumnos(alumno);
                    if (alumnoEncontrado) {
                        javax.swing.JOptionPane.showMessageDialog(null,
                                "Nombre modificado con éxito.");
                    } else {
                        javax.swing.JOptionPane.showMessageDialog(null,
                                "Error al actualizar el alumno.");
                    }
                    break;
                }
            }

            if (!alumnoEncontrado) {
                javax.swing.JOptionPane.showMessageDialog(null,
                        "No se encontró un alumno con la matrícula proporcionada.");
            }
        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(null,
                    "Ingresa un valor numérico válido para la matrícula.");
        } finally {
            restablecerInterfaz();
        }
    }

    private void modificarApellido() {
        try {
            int matriculaParaModificar = Integer.parseInt(txtMat.getText().trim());
            String nuevoApellido = txtAp.getText().trim();

            dao.DaoAlumno daoAlumnos = new dao.DaoAlumno();
            Paradigmas_2 alumnoModificado = null;

            java.util.ArrayList<Paradigmas_2> listaAlumnos = daoAlumnos.readAlumnos();
            for (Paradigmas_2 alumno : listaAlumnos) {
                if (alumno.getMat() == matriculaParaModificar) {
                    alumnoModificado = new Paradigmas_2(alumno.getMat(),
                            alumno.getNom(), nuevoApellido, alumno.getCarrera(),
                            alumno.getEdad(), alumno.getSemes());
                    break;
                }
            }

            if (alumnoModificado != null) {
                boolean actualizado = daoAlumnos.updateAlumnos(alumnoModificado);
                if (actualizado) {
                    javax.swing.JOptionPane.showMessageDialog(null,
                            "Apellido modificado con éxito.");
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null,
                            "Error al actualizar el alumno.");
                }
            } else {
                javax.swing.JOptionPane.showMessageDialog(null,
                        "No se encontró un alumno con la matrícula proporcionada.");
            }
        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(null,
                    "Ingresa un valor numérico válido para la matrícula.");
        } finally {
            restablecerInterfaz();
        }
    }

    private void modificarCarrera() {
        try {
            int matriculaParaModificar = Integer.parseInt(txtMat.getText().trim());
            String nuevaCarrera = (String) cmbCarrera.getSelectedItem();

            dao.DaoAlumno daoAlumnos = new dao.DaoAlumno();
            Paradigmas_2 alumnoModificado = null;

            java.util.ArrayList<Paradigmas_2> listaAlumnos = daoAlumnos.readAlumnos();
            for (Paradigmas_2 alumno : listaAlumnos) {
                if (alumno.getMat() == matriculaParaModificar) {
                    alumnoModificado = new Paradigmas_2(alumno.getMat(), alumno.getNom(), alumno.getAp(), nuevaCarrera, alumno.getEdad(), alumno.getSemes());
                    break;
                }
            }

            if (alumnoModificado != null) {
                boolean actualizado = daoAlumnos.updateAlumnos(alumnoModificado);
                if (actualizado) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Carrera modificada con éxito.");
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Error al actualizar el alumno.");
                }
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "No se encontró un alumno con la matrícula proporcionada.");
            }
        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Ingresa un valor numérico válido para la matrícula.");
        } finally {
            restablecerInterfaz();
        }
    }

    private void modificarEdad() {
        try {
            int matriculaParaModificar = Integer.parseInt(txtMat.getText().trim());
            int nuevaEdad = Integer.parseInt(txtEd.getText().trim());

            if (nuevaEdad < 0 || nuevaEdad > 100) {
                javax.swing.JOptionPane.showMessageDialog(null,
                        "La edad debe estar en el rango de 0 a 100.");
                return;
            }

            dao.DaoAlumno daoAlumnos = new dao.DaoAlumno();
            Paradigmas_2 alumnoModificado = null;

            java.util.ArrayList<Paradigmas_2> listaAlumnos = daoAlumnos.readAlumnos();
            for (Paradigmas_2 alumno : listaAlumnos) {
                if (alumno.getMat() == matriculaParaModificar) {
                    alumnoModificado = new Paradigmas_2(alumno.getMat(),
                            alumno.getNom(), alumno.getAp(), alumno.getCarrera(),
                            (byte) nuevaEdad, alumno.getSemes());
                    break;
                }
            }

            if (alumnoModificado != null) {
                boolean actualizado = daoAlumnos.updateAlumnos(alumnoModificado);
                if (actualizado) {
                    javax.swing.JOptionPane.showMessageDialog(null,
                            "Edad modificada con éxito.");
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null,
                            "Error al actualizar el alumno.");
                }
            } else {
                javax.swing.JOptionPane.showMessageDialog(null,
                        "No se encontró un alumno con la matrícula proporcionada.");
            }
        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(null,
                    "Ingresa valores numéricos válidos para la matrícula y la edad.");
        } finally {
            restablecerInterfaz();
        }
    }

    private void modificarSemestre() {
        try {
            int matriculaParaModificar = Integer.parseInt(txtMat.getText().trim());
            int nuevoSemestre = Integer.parseInt(txtSem.getText().trim());

            if (nuevoSemestre < 1 || nuevoSemestre > 12) {
                javax.swing.JOptionPane.showMessageDialog(null,
                        "El semestre debe estar en el rango de 1 a 12.");
                return;
            }

            dao.DaoAlumno daoAlumnos = new dao.DaoAlumno();
            Paradigmas_2 alumnoModificado = null;

            java.util.ArrayList<Paradigmas_2> listaAlumnos = daoAlumnos.readAlumnos();
            for (Paradigmas_2 alumno : listaAlumnos) {
                if (alumno.getMat() == matriculaParaModificar) {
                    alumnoModificado = new Paradigmas_2(alumno.getMat(),
                            alumno.getNom(), alumno.getAp(), alumno.getCarrera(),
                            alumno.getEdad(), (byte) nuevoSemestre);
                    break;
                }
            }

            if (alumnoModificado != null) {
                boolean actualizado = daoAlumnos.updateAlumnos(alumnoModificado);
                if (actualizado) {
                    javax.swing.JOptionPane.showMessageDialog(null,
                            "Semestre modificado con éxito.");
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null,
                            "Error al actualizar el alumno.");
                }
            } else {
                javax.swing.JOptionPane.showMessageDialog(null,
                        "No se encontró un alumno con la matrícula proporcionada.");
            }
        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(null,
                    "Ingresa valores numéricos válidos para la matrícula y el semestre.");
        } finally {
            restablecerInterfaz();
        }
    }

    private void restablecerInterfaz() {
        ocultarComponentes();
        txtMat.setText("");
        txtNom.setText("");
        txtAp.setText("");
    cmbCarrera.setSelectedIndex(0);
        txtEd.setText("");
        txtSem.setText("");
    }

    private void btnMenuActionPerfomed(java.awt.event.ActionEvent e) {
        this.dispose();
    }

    @Override
    public void actionPerformed(java.awt.event.ActionEvent e) {
        if (e.getSource() == btnModNom) {
            lblMat.setVisible(true);
            txtMat.setVisible(true);
            lblNom.setVisible(true);
            txtNom.setVisible(true);
            lblAp.setVisible(false);
            txtAp.setVisible(false);
            cmbCarrera.setVisible(false);
            btnConfirmar.setVisible(true);
        } else if (e.getSource() == btnModAp) {
            lblMat.setVisible(true);
            txtMat.setVisible(true);
            lblNom.setVisible(false);
            txtNom.setVisible(false);
            lblAp.setVisible(true);
            txtAp.setVisible(true);
            cmbCarrera.setVisible(false);
            btnConfirmar.setVisible(true);
        } else if (e.getSource() == btnModCa) {
            lblMat.setVisible(true);
            txtMat.setVisible(true);
            lblNom.setVisible(false);
            txtNom.setVisible(false);
            lblAp.setVisible(false);
            txtAp.setVisible(false);
            cmbCarrera.setVisible(true);
            btnConfirmar.setVisible(true);
        } else if (e.getSource() == btnModEd) {
            lblMat.setVisible(true);
            txtMat.setVisible(true);
            lblNom.setVisible(false);
            txtNom.setVisible(false);
            lblAp.setVisible(false);
            txtAp.setVisible(false);
            cmbCarrera.setVisible(false);
            lblEd.setVisible(true);
            txtEd.setVisible(true);
            btnConfirmar.setVisible(true);
        } else if (e.getSource() == btnModSem) {
            lblMat.setVisible(true);
            txtMat.setVisible(true);
            lblNom.setVisible(false);
            txtNom.setVisible(false);
            lblAp.setVisible(false);
            txtAp.setVisible(false);
            cmbCarrera.setVisible(false);
            lblEd.setVisible(false);
            txtEd.setVisible(false);
            lblSem.setVisible(true);
            txtSem.setVisible(true);
            btnConfirmar.setVisible(true);
        } else if (e.getSource() == btnMenu) {
            btnMenuActionPerfomed(e);
        }
        this.revalidate();
        this.repaint();
    }

    private javax.swing.JLabel lblOpcs;
    private javax.swing.JButton btnModNom;
    private javax.swing.JButton btnModAp;
    private javax.swing.JButton btnModCa;
    private javax.swing.JButton btnModEd;
    private javax.swing.JButton btnModSem;
    private javax.swing.JButton btnMenu;
    private javax.swing.JLabel lblMat;
    private javax.swing.JTextField txtMat;
    private javax.swing.JLabel lblNom;
    private javax.swing.JTextField txtNom;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JLabel lblAp;
    private javax.swing.JTextField txtAp;
    private javax.swing.JComboBox<String> cmbCarrera;
    private javax.swing.JLabel lblEd;
    private javax.swing.JTextField txtEd;
    private javax.swing.JLabel lblSem;
    private javax.swing.JTextField txtSem;
}
