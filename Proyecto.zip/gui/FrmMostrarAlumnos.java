package gui;

import dao.DaoAlumno;
import model.Paradigmas_2;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class FrmMostrarAlumnos extends javax.swing.JDialog implements ActionListener {

    private javax.swing.JButton btnAnterior, btnSiguiente, btnRegresarMenu;
    private javax.swing.JTable tablaDetalles;
    private DefaultTableModel modeloTabla;
    private ArrayList<Paradigmas_2> listaAlumnos;
    private int indiceActual = 0;

    private DaoAlumno daoAlumno = new DaoAlumno();

    public FrmMostrarAlumnos(ArrayList<Paradigmas_2> listaAlumnos) {
        this.listaAlumnos = listaAlumnos;
        initComponents();
        actualizarDetalleAlumno();
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Mostrar Alumnos");
        setSize(500, 400);
        setLayout(null);

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Matricula");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Apellido");
        modeloTabla.addColumn("Carrera");
        modeloTabla.addColumn("Edad");
        modeloTabla.addColumn("Semestre");

        tablaDetalles = new javax.swing.JTable(modeloTabla);
        javax.swing.JScrollPane scrollPane = new javax.swing.JScrollPane(tablaDetalles);
        scrollPane.setBounds(10, 10, 480, 300);
        add(scrollPane);

        btnAnterior = new javax.swing.JButton("Anterior");
        btnSiguiente = new javax.swing.JButton("Siguiente");
        btnRegresarMenu = new javax.swing.JButton("MENU PRINCIPAL");

        btnAnterior.setBounds(10, 320, 150, 25);
        btnSiguiente.setBounds(170, 320, 150, 25);
        btnRegresarMenu.setBounds(330, 320, 150, 25);

        add(btnAnterior);
        add(btnSiguiente);
        add(btnRegresarMenu);

        btnAnterior.addActionListener(this);
        btnSiguiente.addActionListener(this);
        btnRegresarMenu.addActionListener(this);
    }

    private void actualizarDetalleAlumno() {
        modeloTabla.setRowCount(0);
        if (!listaAlumnos.isEmpty() && indiceActual >= 0 && indiceActual < listaAlumnos.size()) {
            Paradigmas_2 alumno = listaAlumnos.get(indiceActual);
            modeloTabla.addRow(new Object[]{
                alumno.getMat(),
                alumno.getNom(),
                alumno.getAp(),
                alumno.getCarrera(),
                alumno.getEdad(),
                alumno.getSemes()
            });
        } else if (indiceActual >= listaAlumnos.size()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ya no hay más registros para mostrar.");
            indiceActual = listaAlumnos.size() - 1;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAnterior) {
            if (indiceActual > 0) {
                indiceActual--;
                actualizarDetalleAlumno();
            } else {
                javax.swing.JOptionPane.showMessageDialog(this, "No existen registros anteriores.");
            }
        } else if (e.getSource() == btnSiguiente) {
            if (indiceActual < listaAlumnos.size() - 1) {
                indiceActual++;
                actualizarDetalleAlumno();
            } else {
                javax.swing.JOptionPane.showMessageDialog(this, "Ya no hay más registros para mostrar.");
            }
        } else if (e.getSource() == btnRegresarMenu) {
            this.dispose();
        }
    }
}
