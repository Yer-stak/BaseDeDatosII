package gui;

import model.Paradigmas_2;

public class FrmBajas extends javax.swing.JDialog implements java.awt.event.ActionListener {

    private javax.swing.JButton btnEliminar, btnRegresarMenu, btnCargarDatos;
    private javax.swing.JLabel lblMatricula;
    private javax.swing.JTextField txtMatricula;
    private javax.swing.JTable tablaAlumnos;
    private javax.swing.table.DefaultTableModel modeloTabla;
    private javax.swing.JScrollPane scrollPane;

    public FrmBajas() {
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setTitle("BAJAS ALUMNOS");
        setLayout(null);

        // Matricula
        lblMatricula = new javax.swing.JLabel("Matricula:");
        lblMatricula.setBounds(10, 10, 200, 30);
        txtMatricula = new javax.swing.JTextField(10);
        txtMatricula.setBounds(210, 10, 150, 30);

        // Botones
        btnEliminar = new javax.swing.JButton("Eliminar");
        btnEliminar.setBounds(370, 10, 150, 30);
        btnRegresarMenu = new javax.swing.JButton("Regresar al Menú Principal");
        btnRegresarMenu.setBounds(10, 330, 200, 30);
        btnCargarDatos = new javax.swing.JButton("Cargar Datos");
        btnCargarDatos.setBounds(220, 330, 150, 30);

        String[] columnas = {"Matrícula", "Nombre", "Apellido", "Carrera", "Edad", "Semestre"};
        modeloTabla = new javax.swing.table.DefaultTableModel(null, columnas);
        tablaAlumnos = new javax.swing.JTable(modeloTabla);
        scrollPane = new javax.swing.JScrollPane(tablaAlumnos);
        scrollPane.setBounds(10, 50, 560, 270);

        add(lblMatricula);
        add(txtMatricula);
        add(btnEliminar);
        add(btnRegresarMenu);
       
        add(scrollPane);

        btnRegresarMenu.addActionListener(this);
        btnEliminar.addActionListener(this);
        
          cargarDatosEnTabla();
    }

    private void LimpiarCampo() {
        txtMatricula.setText("");
    }

    private void cargarDatosEnTabla() {
        modeloTabla.setRowCount(0);
        java.util.ArrayList<Paradigmas_2> listaAlumnos = cargarDatos();
        for (Paradigmas_2 alumno : listaAlumnos) {
            Object[] fila = new Object[]{
                alumno.getMat(),
                alumno.getNom(),
                alumno.getAp(),
                alumno.getCarrera(),
                alumno.getEdad(),
                alumno.getSemes()
            };
            modeloTabla.addRow(fila);
        }
    }

    private java.util.ArrayList<Paradigmas_2> cargarDatos() {
        dao.DaoAlumno daoAlumno = new dao.DaoAlumno();
        java.util.ArrayList<Paradigmas_2> listaAlumnos = daoAlumno.readAlumnos();
    return listaAlumnos;
    }

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent e) {
        int confirmacion = javax.swing.JOptionPane.showConfirmDialog(this,
                "¿Está seguro que desea eliminar a este alumno?",
                "Confirmar eliminación", javax.swing.JOptionPane.YES_NO_OPTION);
        if (confirmacion == javax.swing.JOptionPane.YES_OPTION) {
            try {
                int matricula = Integer.parseInt(txtMatricula.getText().trim());
                Paradigmas_2 alumnoAEliminar = new Paradigmas_2();
                alumnoAEliminar.setMat(matricula);

                dao.DaoAlumno daoAlumno = new dao.DaoAlumno();
                boolean eliminado = daoAlumno.deleteAlumnos(alumnoAEliminar);

                if (eliminado) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Alumno eliminado con éxito.");
                    cargarDatosEnTabla();
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Matrícula no encontrada.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(null, "Por favor, ingrese una matrícula válida.");
            }
        }
        LimpiarCampo();
    }

    private void btnRegresarMenuActionPerformed(java.awt.event.ActionEvent e) {
        this.dispose();
    }

    @Override
    public void actionPerformed(java.awt.event.ActionEvent e) {
        if (e.getSource() == btnEliminar) {
            btnEliminarActionPerformed(e);
        } else if (e.getSource() == btnRegresarMenu) {
            btnRegresarMenuActionPerformed(e);
        } else if (e.getSource() == btnCargarDatos) {
            cargarDatosEnTabla();
        }
    }

}
