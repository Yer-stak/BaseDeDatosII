package d0212024;


public class Principal {
    
    public static void main(String[] args) {
        
        FrmMenuPrincipal m= new FrmMenuPrincipal();
        
        m.setVisible(true);
        
    }
}
