
package idao;

import model.Carrera;
import java.util.ArrayList;

public interface ICarrera {
    void createCarrera(Carrera a);
        ArrayList<Carrera> readCarrera();
        boolean updateCarrera(Carrera a);
        boolean deleteCarrera(Carrera a);
}
