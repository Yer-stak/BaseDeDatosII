/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package idao;

import java.util.ArrayList;
import model.Profesores;

/**
 *
 * @author angel
 */
public interface IProfesores {
    
    void createProfesores(Profesores a);
        ArrayList<Profesores> readProfesores();
        boolean updateProfesores(Profesores a);
        boolean deleteProfesores(Profesores a);
}
