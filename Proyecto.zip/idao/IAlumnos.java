package idao;

import java.util.ArrayList;
import model.Paradigmas_2;


public interface IAlumnos {
    
        void createAlumnos(Paradigmas_2 a);
        ArrayList<Paradigmas_2> readAlumnos();
        boolean updateAlumnos(Paradigmas_2 a);
        boolean deleteAlumnos(Paradigmas_2 a);
       
}
