package dao;

import Utilerias.Conexion;
import idao.IAlumnos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Paradigmas_2;

public class DaoAlumno implements IAlumnos {

    private final Conexion conexion;

    public DaoAlumno() {
        conexion = new Conexion();
    }

    @Override
    public void createAlumnos(Paradigmas_2 a) {
        String sql = "INSERT INTO alumno (matricula, nombre, apellidos, carrera, edad, semestre)"
                + " VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, a.getMat());
            ps.setString(2, a.getNom());
            ps.setString(3, a.getAp());
            ps.setString(4, a.getCarrera());
            ps.setByte(5, a.getEdad());
            ps.setByte(6, a.getSemes());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error al crear alumno: " + ex.getMessage());
        }
    }

    @Override
    public ArrayList<Paradigmas_2> readAlumnos() {
        ArrayList<Paradigmas_2> alumnos = new ArrayList<>();
        String sql = "SELECT * FROM alumno";
        try (Connection conn = conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                alumnos.add(new Paradigmas_2(rs.getInt("matricula"),
                        rs.getString("nombre"),
                        rs.getString("apellidos"), rs.getString("carrera"),
                        rs.getByte("edad"), rs.getByte("semestre")));
            }
        } catch (SQLException ex) {
            System.out.println("Error al leer alumnos: " + ex.getMessage());
        }
        return alumnos;
    }

    @Override
    public boolean updateAlumnos(Paradigmas_2 a) {
        String sql = "UPDATE alumno SET nombre = ?, apellidos = ?, carrera = ?, edad = ?, semestre = ? WHERE matricula = ?";
        try (Connection conn = conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getNom());
            ps.setString(2, a.getAp());
            ps.setString(3, a.getCarrera());
            ps.setByte(4, a.getEdad());
            ps.setByte(5, a.getSemes());
            ps.setInt(6, a.getMat());

            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            System.out.println("Error al actualizar alumno: " + ex.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteAlumnos(Paradigmas_2 alumnoAEliminar) {
        String sql = "DELETE FROM alumno WHERE matricula = ?";
        try (Connection conn = conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, alumnoAEliminar.getMat());
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar alumno: " + ex.getMessage());
            return false;
        }
    }

}
