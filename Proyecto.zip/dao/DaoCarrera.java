package dao;

import Utilerias.Conexion;
import idao.ICarrera;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Carrera;

public class DaoCarrera implements ICarrera {

    private final Conexion conexion;

    public DaoCarrera() {
        conexion = new Conexion();
    }

    @Override
    public void createCarrera(Carrera a) {
        Connection conn = conexion.getConexion();
        String sql = "INSERT INTO Carrera (idCar, nomCar, duracion) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setByte(1, a.getIdCar());
            ps.setString(2, a.getNomCar());
            ps.setInt(3, a.getDuracion());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    @Override
    public ArrayList<Carrera> readCarrera() {
        ArrayList<Carrera> carreras = new ArrayList<>();
        Connection conn = conexion.getConexion();
        String sql = "SELECT * FROM Carrera";
        try (PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                byte idCar = rs.getByte("idCar");
                String nomCar = rs.getString("nomCar");
                int duracion = rs.getInt("duracion");
                Carrera carrera = new Carrera(idCar, nomCar, duracion);
                carreras.add(carrera);
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return carreras;
    }

    @Override
    public boolean updateCarrera(Carrera a) {
        Connection conn = conexion.getConexion();
        String sql = "UPDATE Carrera SET nomCar = ?, duracion = ? WHERE idCar = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getNomCar());
            ps.setInt(2, a.getDuracion());
            ps.setByte(3, a.getIdCar());
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteCarrera(Carrera a) {
        Connection conn = conexion.getConexion();
        String sql = "DELETE FROM Carrera WHERE idCar = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setByte(1, a.getIdCar());
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
            return false;
        }
    }
}
