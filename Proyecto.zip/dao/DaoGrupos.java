package dao;

import Utilerias.Conexion;
import idao.IGrupos;
import model.Grupos;
import model.Materia;
import model.Paradigmas_2;
import model.Profesores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DaoGrupos implements IGrupos {

    private final Conexion conexion;

    public DaoGrupos() {
        this.conexion = new Conexion();
    }

    @Override
    public void createGrupo(Grupos grupo) {
        String sqlGrupo = "INSERT INTO grupo (id, idProfesor, idMateria) VALUES (?, ?, ?)";
        String sqlGrupoAlumno = "INSERT INTO alumno_grupo (idGrupo, idAlumno) VALUES (?, ?)";
        try (Connection conn = conexion.getConexion(); PreparedStatement psGrupo = conn.prepareStatement(sqlGrupo); PreparedStatement psGrupoAlumno = conn.prepareStatement(sqlGrupoAlumno)) {
            conn.setAutoCommit(false);
            psGrupo.setInt(1, grupo.getIdGrupo());
            psGrupo.setInt(2, grupo.getProfesor().getIdProf());
            psGrupo.setInt(3, grupo.getMateria().getIdMat());
            psGrupo.executeUpdate();

            for (Paradigmas_2 alumno : grupo.getAlumnos()) {
                psGrupoAlumno.setInt(1, grupo.getIdGrupo());
                psGrupoAlumno.setInt(2, alumno.getMat());
                psGrupoAlumno.executeUpdate();
            }

            conn.commit();
        } catch (SQLException ex) {
            System.err.println("Error al crear el grupo: " + ex.getMessage());
        }
    }

    @Override
    public ArrayList<Grupos> readGrupos() {
        ArrayList<Grupos> grupos = new ArrayList<>();
        String sql = "SELECT g.id, p.id AS idProf, p.nombre AS nomProf, p.apellidos AS apProf, m.id AS idMat, m.nombre AS nomMat, m.creditos "
                + "FROM grupo g "
                + "INNER JOIN profesor p ON g.idProfesor = p.id "
                + "INNER JOIN materia m ON g.idMateria = m.id";
        try (Connection conn = conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Profesores profesor = new Profesores(rs.getInt("idProf"), rs.getString("nomProf"), rs.getString("apProf"));
                Materia materia = new Materia(rs.getInt("idMat"), rs.getString("nomMat"), rs.getFloat("creditos"));
                Grupos grupo = new Grupos(rs.getInt("id"), profesor, materia, new ArrayList<>());
              
                grupo.setAlumnos(cargarAlumnosDelGrupo(rs.getInt("id"), conn));
                grupos.add(grupo);
            }
        } catch (SQLException ex) {
            System.err.println("Error al leer los grupos: " + ex.getMessage());
        }
        return grupos;
    }

    private ArrayList<Paradigmas_2> cargarAlumnosDelGrupo(int idGrupo, Connection conn) {
        ArrayList<Paradigmas_2> alumnos = new ArrayList<>();
        String sql = "SELECT a.matricula, a.nombre FROM alumno a INNER JOIN alumno_grupo ag ON a.matricula = ag.idAlumno WHERE ag.idGrupo = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idGrupo);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Paradigmas_2 alumno = new Paradigmas_2();
                    alumno.setMat(rs.getInt("matricula"));
                    alumno.setNom(rs.getString("nombre"));
                    
                    alumnos.add(alumno);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar alumnos del grupo " + idGrupo + ": " + e.getMessage());
        }
        return alumnos;
    }

      public boolean eliminarReferenciasGrupo(int idGrupo) {
        String sql = "DELETE FROM alumno_grupo WHERE idGrupo = ?";
        try (Connection conn = conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idGrupo);
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar las referencias del grupo: " + ex.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteGrupos(Grupos grupo) {
        
        if (!eliminarReferenciasGrupo(grupo.getIdGrupo())) {
            System.err.println("Error al eliminar las referencias del grupo " + grupo.getIdGrupo());
            return false;
        }
        
        
        String sql = "DELETE FROM grupo WHERE id = ?";
        try (Connection conn = conexion.getConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, grupo.getIdGrupo());
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar el grupo: " + ex.getMessage());
            return false;
        }
    }
}

