package dao;

import Utilerias.Conexion;
import idao.IProfesores;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Profesores;

public class DaoProfesores implements IProfesores {

    private final Conexion conexion;

    public DaoProfesores() {
        conexion = new Conexion();
    }

    @Override
    public void createProfesores(Profesores p) {
        Connection conn = conexion.getConexion();
        String sql = "INSERT INTO profesor (id, nombre, apellidos) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, p.getIdProf());
            ps.setString(2, p.getNomProf());
            ps.setString(3, p.getApProf());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    @Override
    public ArrayList<Profesores> readProfesores() {
        ArrayList<Profesores> profesores = new ArrayList<>();
        Connection conn = conexion.getConexion();
        String sql = "SELECT * FROM profesor";
        try (PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int idProf = rs.getInt("id");
                String nomProf = rs.getString("nombre");
                String apProf = rs.getString("apellidos");
                Profesores profesor = new Profesores(idProf, nomProf, apProf);
                profesores.add(profesor);
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return profesores;
    }

    @Override
    public boolean updateProfesores(Profesores p) {
        Connection conn = conexion.getConexion(); 
        String sql = "UPDATE profesor SET nombre = ?, apellidos = ? WHERE id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getNomProf());
            ps.setString(2, p.getApProf());
            ps.setInt(3, p.getIdProf());

            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteProfesores(Profesores p) {
        Connection conn = conexion.getConexion();
        String sql = "DELETE FROM profesor WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, p.getIdProf());
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
            return false;
        }
    }

}
