package dao;

import Utilerias.Conexion;
import idao.IMateria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Materia;

public class DaoMateria implements IMateria {

    private final Conexion conexion;

    public DaoMateria() {
        conexion = new Conexion();
    }

    @Override
    public void createMateria(Materia m) {
        Connection conn = conexion.getConexion();
        String sql = "INSERT INTO materia (id, nombre, creditos) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, m.getIdMat());
            ps.setString(2, m.getNomMat());
            ps.setFloat(3, m.getCreditos());
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

   @Override
public ArrayList<Materia> readMateria() {
    ArrayList<Materia> materias = new ArrayList<>();
    Connection conn = conexion.getConexion();
    String sql = "SELECT * FROM materia"; 
    try (PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            int idMat = rs.getInt("id"); 
            String nomMat = rs.getString("nombre"); 
            float creditos = rs.getFloat("creditos");
            Materia materia = new Materia(idMat, nomMat, creditos);
            materias.add(materia);
        }
    } catch (SQLException ex) {
        System.out.println("Error: " + ex.getMessage());
    }
    return materias;
}


    @Override
public boolean updateMateria(Materia m) {
    Connection conn = conexion.getConexion();
    String sql = "UPDATE materia SET nombre = ?, creditos = ? WHERE id = ?"; 
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, m.getNomMat());
        ps.setFloat(2, m.getCreditos());
        ps.setInt(3, m.getIdMat());
        int affectedRows = ps.executeUpdate();
        return affectedRows > 0;
    } catch (SQLException ex) {
        System.out.println("Error: " + ex.getMessage());
        return false;
    }
}

@Override
public boolean deleteMateria(Materia m) {
    Connection conn = conexion.getConexion();
    String sql = "DELETE FROM materia WHERE id = ?"; 
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, m.getIdMat());
        int affectedRows = ps.executeUpdate();
        return affectedRows > 0;
    } catch (SQLException ex) {
        System.out.println("Error: " + ex.getMessage());
        return false;
    }
}

}
