package model;

public class Materia implements java.io.Serializable{

    private int idMat;
    private String nomMat;
    private float creditos;

    public int getIdMat() {
        return idMat;
    }

    public void setIdMat(int idMat) {
        this.idMat = idMat;
    }

    public String getNomMat() {
        return nomMat;
    }

    public void setNomMat(String nomMat) {
        this.nomMat = nomMat;
    }

    public float getCreditos() {
        return creditos;
    }

    public void setCreditos(float creditos) {
        this.creditos = creditos;
    }

    public Materia(int idMat, String nomMat, float creditos) {
        this.idMat = idMat;
        this.nomMat = nomMat;
        this.creditos = creditos;
    }

}
