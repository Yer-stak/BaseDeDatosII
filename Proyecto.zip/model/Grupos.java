
package model;

/**
 *
 * @author angel
 */
public class Grupos implements java.io.Serializable {

    private int idGrupo;
    private Profesores profesor;
    private Materia materia;
    private java.util.ArrayList<Paradigmas_2> alumnos;
    
    public Grupos() {
       
    }
    
     public Grupos(int idGrupo) {
        this.idGrupo = idGrupo;
    }

    public Grupos(int idGrupo, Profesores profesor, Materia materia, java.util.ArrayList<Paradigmas_2> alumnos) {
        this.idGrupo = idGrupo;
        this.profesor = profesor;
        this.materia = materia;
        this.alumnos = alumnos;
    }

    public int getIdGrupo() {
        return idGrupo;
    }

    public void setIdGrupo(int idGrupo) {
        this.idGrupo = idGrupo;
    }

    public Profesores getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesores profesor) {
        this.profesor = profesor;
    }

    public Materia getMateria() {
        return materia;
    }

    public void setMateria(Materia materia) {
        this.materia = materia;
    }

    public java.util.ArrayList<Paradigmas_2> getAlumnos() {
        return alumnos;
    }

    public void setAlumnos(java.util.ArrayList<Paradigmas_2> alumnos) {
        this.alumnos = alumnos;
    }
}
