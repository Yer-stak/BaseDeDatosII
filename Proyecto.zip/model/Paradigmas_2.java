package model;

public class Paradigmas_2 implements java.io.Serializable{

    private int mat;
    private String nom, ap, carrera;
    private byte edad, semes;

    public Paradigmas_2() {
        this.mat = 0;
        this.nom = "";
        this.ap = "";
        this.carrera = "";
        this.edad = 0;
        this.semes = 0;
    
    }

    public int getMat() {
        return mat;
    }

    public void setMat(int mat) {
        this.mat = mat;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAp() {
        return ap;
    }

    public void setAp(String ap) {
        this.ap = ap;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public byte getEdad() {
        return edad;
    }

    public void setEdad(byte edad) {
        this.edad = edad;
    }

    public byte getSemes() {
        return semes;
    }

    public void setSemes(byte semes) {
        this.semes = semes;
    }

    public Paradigmas_2(int mat, String nom, String ap, String carrera, byte edad, byte semes) {
        this.mat = mat;
        this.nom = nom;
        this.ap = ap;
        this.carrera = carrera;
        this.edad = edad;
        this.semes = semes;
    }

    @Override
    public String toString() {
        return String.format("%-10d %-15s %-20s %-5d %-30s %-10d",
                mat, nom, ap, edad, carrera, semes);
    }
}