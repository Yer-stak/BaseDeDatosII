package model;

public class Profesores implements java.io.Serializable {

    private int idProf;
    private String nomProf, apProf;

   
    public Profesores() {
    }

   
    public Profesores(int idProf, String nomProf, String apProf) {
        this.idProf = idProf;
        this.nomProf = nomProf;
        this.apProf = apProf;
    }

   
    public int getIdProf() {
        return idProf;
    }

    public void setIdProf(int idProf) {
        this.idProf = idProf;
    }

    public String getNomProf() {
        return nomProf;
    }

    public void setNomProf(String nomProf) {
        this.nomProf = nomProf;
    }

    public String getApProf() {
        return apProf;
    }

    public void setApProf(String apProf) {
        this.apProf = apProf;
    }
}
