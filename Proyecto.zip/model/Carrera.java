package model;

public class Carrera implements java.io.Serializable{

    private byte idCar;
    private String nomCar;
    private int duracion;

    public byte getIdCar() {
        return idCar;
    }

    public void setIdCar(byte idCar) {
        this.idCar = idCar;
    }

    public String getNomCar() {
        return nomCar;
    }

    public void setNomCar(String nomCar) {
        this.nomCar = nomCar;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public Carrera(byte idCar, String nomCar, int duracion) {
        this.idCar = idCar;
        this.nomCar = nomCar;
        this.duracion = duracion;
    }
}
